package com.example.gudep.inclass08;

import android.os.Parcel;
import android.os.Parcelable;

/**
* Created by gudep on 10/17/2016.
*/



public class Expense implements Parcelable, Comparable<Expense>{

    public String ExpenseName, category, amount, date, image;

    public Expense(String expenseName, String category, String amount, String date) {
        this.ExpenseName = expenseName;
        this.category = category;
        this.amount = amount;
        this.date = date;
    }

    protected Expense(Parcel in) {
        ExpenseName = in.readString();
        category = in.readString();
        amount = in.readString();
        date = in.readString();
        image = in.readString();
    }
    protected Expense()
    {

    }

    public static final Creator<Expense> CREATOR = new Creator<Expense>() {
        @Override
        public Expense createFromParcel(Parcel in) {
            return new Expense(in);
        }

        @Override
        public Expense[] newArray(int size) {
            return new Expense[size];
        }
    };

    public String getExpenseName() {
        return ExpenseName;
    }

    public void setExpenseName(String expenseName) {
        ExpenseName = expenseName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }




    @Override
    public String toString() {
        return "Expense{" +
                "ExpenseName='" + ExpenseName + '\'' +
                ", category='" + category + '\'' +
                ", amount='" + amount + '\'' +
                ", date='" + date + '\'' +
                '}';
    }


    @Override
    public int compareTo(Expense expense) {
        return this.ExpenseName.compareToIgnoreCase(expense.ExpenseName);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ExpenseName);
        dest.writeString(category);
        dest.writeString(amount);
        dest.writeString(date);
    }
}

