package com.example.gudep.inclass08;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ExpenseFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ExpenseFragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    ListView listview;
    TextView messageTV;
    //ImageView plusSymbol;

    public ExpenseFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_expense, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        listview=(ListView) getActivity().findViewById(R.id.ListViewExpenses);
        listview.setVisibility(View.INVISIBLE);
        //plusSymbol = (ImageView) getActivity().findViewById(R.id.plusSymbol);
        //TextView currentExpTV = (TextView) getView().findViewById(R.id.CurrentExpTV);
        messageTV = (TextView) getActivity().findViewById(R.id.messageTV);

        getActivity().findViewById(R.id.imageView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onAddExpenseClicked();
                //Log.d("demo","Hey vachindi");
                //Toast.makeText(getActivity(), "Hey U clicked", Toast.LENGTH_SHORT).show();
            }
        });


    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        displayList();
    }

    public void displayList() {
        MainActivity activity = (MainActivity) mListener;
        showDetails(activity.expenses);
    }

    public void showDetails(ArrayList<Expense> expenses) {
        if(expenses.size()==0)
        {
            messageTV.setVisibility(View.VISIBLE);
            listview.setVisibility(View.INVISIBLE);
        }
        else{
            messageTV.setVisibility(View.INVISIBLE);
            listview.setVisibility(View.VISIBLE);
            ExpenseAdapter adapter = new ExpenseAdapter(getActivity(),R.layout.row_layout,expenses);
            listview.setAdapter(adapter);

            listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    mListener.showExpDetails(position);
                }
            });

            listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    MainActivity activity = (MainActivity) mListener;
                    activity.expenses.remove(position);
                    Toast.makeText(getActivity(), "Deleted successfully", Toast.LENGTH_SHORT).show();
                    displayList();
                    return false;
                }
            });
        }
    }

    public void setExpList(){
        MainActivity activity = (MainActivity) mListener;
        if(activity.expenses.size()==0)
        {
            messageTV.setVisibility(View.VISIBLE);
            listview.setVisibility(View.INVISIBLE);
        }
        else{
            messageTV.setVisibility(View.INVISIBLE);
            listview.setVisibility(View.VISIBLE);
            ExpenseAdapter adapter = new ExpenseAdapter(getActivity(),R.layout.row_layout,activity.expenses);
            listview.setAdapter(adapter);
        }
    }

    public interface OnFragmentInteractionListener {

        void onAddExpenseClicked();
        void showExpDetails(int pos);
        //void onListItemClicked();
    }
}
