package com.example.gudep.inclass08;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SecondFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class SecondFragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    EditText expName, amount;
    Date date;
    Spinner category;
    Button AddExpButton,cancelButton;
    String categoryValue ="";
    //static String[] categories = {"Groceries","Transportation","Shopping","rent","trips","utilities","other"};
    //String expenseName, expenseAmount;

    public SecondFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            //mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //TextView expNameView = (TextView) getView().findViewById(R.id.enterExpNameSecFrag);
        AddExpButton = (Button) getView().findViewById(R.id.buttonAddExpense);
        cancelButton = (Button) getView().findViewById(R.id.buttonCancel);
        expName = (EditText) getView().findViewById(R.id.enterExpNameSecFrag);
        category = (Spinner) getView().findViewById(R.id.spinnerCategory);
        amount = (EditText) getView().findViewById(R.id.amtValSecFrag);
        //final String[] selected_value = {""};
        date = new Date();
        SimpleDateFormat formattedDate = new SimpleDateFormat("MM/dd/yy");
        final String newDate = formattedDate.format(date);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });


        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(getActivity(), R.array.category_array,
                        android.R.layout.simple_spinner_item);
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        category.setAdapter(staticAdapter);
        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                categoryValue = (String)adapterView.getItemAtPosition(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /*category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                categoryValue = (String)parent.getItemAtPosition(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/

        AddExpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(expName.getText().toString().equals("")|| amount.getText().toString().equals("") || categoryValue.isEmpty() ){
                    Toast.makeText(getActivity(), "please enter all the details", Toast.LENGTH_SHORT).show();
                }
                else {
                    Expense exp = new Expense(expName.getText().toString(), categoryValue, amount.getText().toString(), newDate);
                    mListener.sendToList(exp);
                    if(getFragmentManager().getBackStackEntryCount()>0) {
                        getFragmentManager().popBackStack();
                    }
                }
            }
        });

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        //void onFragmentInteraction(Uri uri);
        void sendToList(Expense exp);


    }
}
