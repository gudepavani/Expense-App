package com.example.gudep.inclass08;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ExpenseFragment.OnFragmentInteractionListener, SecondFragment.OnFragmentInteractionListener, ShowExpensesFragment.OnFragmentInteractionListener {

    public ArrayList<Expense> expenses = new ArrayList<Expense>();
    Expense selExpense;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        selExpense = new Expense();
        getFragmentManager().beginTransaction()
                .add(R.id.container, new ExpenseFragment(), "firstFragment")
                .commit();
    }

    @Override
    public void onBackPressed() {

        if(getFragmentManager().getBackStackEntryCount() >0)
        {
            getFragmentManager().popBackStack();
        }
        else
        {
            super.onBackPressed();
        }

    }

    @Override
    public void sendToList(Expense exp) {
        expenses.add(exp);
        //Toast.makeText(this, "Expense added", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAddExpenseClicked() {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new SecondFragment(), "secondFragment")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void showExpDetails(int pos) {
        selExpense = expenses.get(pos);
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new ShowExpensesFragment(), "thirdFragment")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
